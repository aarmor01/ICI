package es.ucm.fdi.ici.c2122.practica3.grupo02.rules.pacman.actionsPochas;

import es.ucm.fdi.ici.Action;
import pacman.game.Constants.MOVE;
import pacman.game.Game;

public class TakeAlternativePathToClosestPowerPill implements Action {

	public TakeAlternativePathToClosestPowerPill() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getActionId() {
		// TODO Auto-generated method stub
		return "Take Alternative Path To Closest PowerPill";
	}

	@Override
	public MOVE execute(Game game) {
		// TODO Auto-generated method stub
		return null;
	}

}
